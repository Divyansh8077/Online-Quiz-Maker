import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AdminSignUpServlet")
public class AdminSignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://admin.clo4o60s49oi.ap-south-1.rds.amazonaws.com:3306/OnlineQuizDB";
    private static final String DB_USER = "admin";
    private static final String DB_PASSWORD = "zeline12345";

    // Logger for debugging
    private static final Logger LOGGER = Logger.getLogger(AdminSignupServlet.class.getName());

    public AdminSignupServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        LOGGER.info("Starting doPost method...");

        // Retrieve form data
        String firstName = request.getParameter("firstName");
        LOGGER.info("Received firstName: " + firstName);

        String lastName = request.getParameter("lastName");
        LOGGER.info("Received lastName: " + lastName);

        String email = request.getParameter("email");
        LOGGER.info("Received email: " + email);

        String password = request.getParameter("password");
        LOGGER.info("Received password: [PROTECTED]");

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            LOGGER.info("Attempting to establish database connection...");
            // Establish connection
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            LOGGER.info("Database connection established successfully.");

            // SQL query to insert user data
            String sql = "INSERT INTO adminuser (first_name, last_name, email, password) VALUES (?, ?, ?, ?)";
            LOGGER.info("SQL query prepared.");

            // Simple password hashing (replace with bcrypt for production use)
            String hashedPassword = password;
            LOGGER.info("Password hashed.");

            // Prepare statement
            preparedStatement = connection.prepareStatement(sql);
            LOGGER.info("PreparedStatement created.");

            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, hashedPassword);
            LOGGER.info("PreparedStatement parameters set.");

            // Execute update
            LOGGER.info("Executing SQL query...");
            int rowsInserted = preparedStatement.executeUpdate();
            LOGGER.info("SQL query executed. Rows inserted: " + rowsInserted);

            if (rowsInserted > 0) {
                out.println("<h3>Signup successful! Welcome, " + firstName + " " + lastName + ".</h3>");
                LOGGER.info("Signup successful.");
                response.sendRedirect("adminLogin.html"); // Redirect to a welcome page
            } else {
                out.println("<h3 style='color:red;'>Signup failed. Please try again.</h3>");
                LOGGER.warning("Signup failed: No rows inserted.");
            }

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "An exception occurred.", e);
            out.println("<h3 style='color:red;'>An error occurred: " + e.getMessage() + "</h3>");
        } finally {
            // Clean up resources
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                    LOGGER.info("PreparedStatement closed.");
                }
                if (connection != null) {
                    connection.close();
                    LOGGER.info("Database connection closed.");
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "An exception occurred during resource cleanup.", e);
            }
        }
    }
}