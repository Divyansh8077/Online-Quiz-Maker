import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SignUpServlet")
public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://admin.clo4o60s49oi.ap-south-1.rds.amazonaws.com:3306/OnlineQuizDB";
    private static final String DB_USER = "admin";
    private static final String DB_PASSWORD = "zeline12345";

    public SignupServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve form data
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
          
            // Establish connection
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL query to insert user data
            String sql = "INSERT INTO user (first_name, last_name, email, password) VALUES (?, ?, ?, ?)";

            // Simple password hashing (replace with bcrypt for production use)
            String hashedPassword = password;

            // Prepare statement
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, hashedPassword);

            // Execute update
            int rowsInserted = preparedStatement.executeUpdate();

            if (rowsInserted > 0) {
                out.println("<h3>Signup successful! Welcome, " + firstName + " " + lastName + ".</h3>");
                response.sendRedirect("login.html"); // Redirect to a welcome page
            } else {
                out.println("<h3 style='color:red;'>Signup failed. Please try again.</h3>");
            }

        } catch (Exception e) {
            e.printStackTrace(out);
            out.println("<h3 style='color:red;'>An error occurred: " + e.getMessage() + "</h3>");
        } finally {
            // Clean up resources
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace(out);
            }
        }
    }
}