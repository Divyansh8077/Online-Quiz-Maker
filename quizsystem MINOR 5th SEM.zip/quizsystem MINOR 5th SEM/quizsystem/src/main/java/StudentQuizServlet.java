import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;

@WebServlet("/StudentQuizServlet")
public class StudentQuizServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DB_URL = "jdbc:mysql://admin.clo4o60s49oi.ap-south-1.rds.amazonaws.com:3306/OnlineQuizDB";
    private static final String DB_USER = "admin";
    private static final String DB_PASSWORD = "zeline12345";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        PrintWriter out = response.getWriter();
        String quizId = request.getParameter("quizId");
        String studentId = request.getParameter("studentId");

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Check if test has already been submitted
            String checkSubmissionQuery = "SELECT * FROM quiz_results WHERE student_id = ? AND quiz_id = ?";
            PreparedStatement checkStmt = con.prepareStatement(checkSubmissionQuery);
            checkStmt.setString(1, studentId);
            checkStmt.setInt(2, Integer.parseInt(quizId));
            ResultSet checkRs = checkStmt.executeQuery();

            if (checkRs.next()) {
                // Redirect to "Test Already Submitted" page
            	out.println("<p style='color:red;'>Test Already Submitted!</p>");
                response.sendRedirect("TestAlreadySubmitted.html");
                return;
            }

            // Fetch quiz details and questions as usual
            String quizQuery = "SELECT title, description, time_limit FROM quizzes WHERE quiz_id = ?";
            PreparedStatement quizStmt = con.prepareStatement(quizQuery);
            quizStmt.setInt(1, Integer.parseInt(quizId));
            ResultSet quizRs = quizStmt.executeQuery();

            if (!quizRs.next()) {
                out.println("<p style='color:red;'>Quiz not found!</p>");
                return;
            }

            String quizTitle = quizRs.getString("title");
            String quizDescription = quizRs.getString("description");
            int timeLimit = quizRs.getInt("time_limit");

            String questionsQuery = "SELECT * FROM questions WHERE quiz_id = ?";
            PreparedStatement questionsStmt = con.prepareStatement(questionsQuery);
            questionsStmt.setInt(1, Integer.parseInt(quizId));
            ResultSet questionsRs = questionsStmt.executeQuery();

            ArrayList<String> questions = new ArrayList<>();
            while (questionsRs.next()) {
                String questionHtml = String.format(
                        "<div class='question-container'>" +
                                "<h3>%s</h3>" +
                                "<div class='options'>" +
                                "<label><input type='radio' name='q%s' value='A'> %s</label>" +
                                "<label><input type='radio' name='q%s' value='B'> %s</label>" +
                                "<label><input type='radio' name='q%s' value='C'> %s</label>" +
                                "<label><input type='radio' name='q%s' value='D'> %s</label>" +
                                "</div>" +
                                "</div>",
                        questionsRs.getString("question_text"),
                        questionsRs.getInt("question_id"), questionsRs.getString("option_a"),
                        questionsRs.getInt("question_id"), questionsRs.getString("option_b"),
                        questionsRs.getInt("question_id"), questionsRs.getString("option_c"),
                        questionsRs.getInt("question_id"), questionsRs.getString("option_d")
                );
                questions.add(questionHtml);
            }

            out.println("<!DOCTYPE html>");
            out.println("<html lang='en'>");
            out.println("<head>");
            out.println("<title>" + quizTitle + "</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background-color: #f9f9f9; margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }");
            out.println(".container { width: 60%; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); padding: 20px; }");
            out.println(".quiz-header { text-align: center; margin-bottom: 20px; }");
            out.println(".submit-button { background-color: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; display: block; margin: 20px auto; transition: background-color 0.3s; }");
            out.println(".submit-button:hover { background-color: #218838; }");
            out.println(".question-container { margin-bottom: 20px; }");
            out.println(".options label { display: block; margin-bottom: 5px; }");
            out.println("#timer { font-weight: bold; color: red; }");
            out.println("</style>");
            out.println("<script>");
            out.println("let timeRemaining = " + (timeLimit * 60) + ";");
            out.println("function startTimer() {");
            out.println("  const timer = document.getElementById('timer');");
            out.println("  const interval = setInterval(() => {");
            out.println("    const minutes = Math.floor(timeRemaining / 60);");
            out.println("    const seconds = timeRemaining % 60;");
            out.println("    timer.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;");
            out.println("    if (timeRemaining <= 0) {");
            out.println("      clearInterval(interval);");
            out.println("      document.getElementById('quizForm').submit();");
            out.println("    }");
            out.println("    timeRemaining--;");
            out.println("  }, 1000);");
            out.println("}");
            out.println("window.onload = startTimer;");
            out.println("</script>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='container'>");
            out.println("<div class='quiz-header'>");
            out.println("<h1>" + quizTitle + "</h1>");
            out.println("<span>Time Remaining: <span id='timer'></span></span>");
            out.println("<button class='submit-button' onclick='document.getElementById(\"quizForm\").submit();'>Submit Test</button>");
            out.println("</div>");
            out.println("<p>" + quizDescription + "</p>");
            out.println("<form id='quizForm' action='StudentQuizServlet' method='post'>");
            out.println("<input type='hidden' name='quizId' value='" + quizId + "'>");
            out.println("<input type='hidden' name='studentId' value='" + studentId + "'>");
            for (String questionHtml : questions) {
                out.println(questionHtml);
            }
            out.println("</form>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        } catch (SQLException e) {
            e.printStackTrace(out);
        } finally {
            out.close();
        }
    }

    
    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String studentId = request.getParameter("studentId");
        int quizId = Integer.parseInt(request.getParameter("quizId"));
        int totalQuestions = 0, correctAnswers = 0;

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String questionsQuery = "SELECT question_id, correct_option FROM questions WHERE quiz_id = ?";
            PreparedStatement questionsStmt = con.prepareStatement(questionsQuery);
            questionsStmt.setInt(1, quizId);
            ResultSet rs = questionsStmt.executeQuery();

            String insertResponseQuery = "INSERT INTO student_responses (student_id, quiz_id, question_id, selected_option, is_correct) " +
                    "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertStmt = con.prepareStatement(insertResponseQuery);

            while (rs.next()) {
                int questionId = rs.getInt("question_id");
                String correctOption = rs.getString("correct_option");
                String selectedOption = request.getParameter("q" + questionId);

                boolean isCorrect = selectedOption != null && selectedOption.equals(correctOption);
                if (isCorrect) correctAnswers++;
                totalQuestions++;

                insertStmt.setString(1, studentId);
                insertStmt.setInt(2, quizId);
                insertStmt.setInt(3, questionId);
                insertStmt.setString(4, selectedOption);
                insertStmt.setBoolean(5, isCorrect);
                insertStmt.addBatch();
            }

            insertStmt.executeBatch();

            double percentage = (double) correctAnswers / totalQuestions * 100;

            String insertResultQuery = "INSERT INTO quiz_results (student_id, quiz_id, score_percentage) VALUES (?, ?, ?)";
            PreparedStatement resultStmt = con.prepareStatement(insertResultQuery);
            resultStmt.setString(1, studentId);
            resultStmt.setInt(2, quizId);
            resultStmt.setDouble(3, percentage);
            resultStmt.executeUpdate();

            // Display result in a styled container
            out.println("<!DOCTYPE html>");
            out.println("<html lang='en'>");
            out.println("<head>");
            out.println("<title>Quiz Results</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background-color: #f9f9f9; margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }");
            out.println(".container { width: 40%; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); padding: 20px; text-align: center; }");
            out.println("h1 { font-size: 24px; margin-bottom: 10px; color: #333; }");
            out.println("p { font-size: 18px; margin-bottom: 10px; color: #555; }");
            out.println(".score { font-size: 20px; font-weight: bold; color: #28a745; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='container'>");
            out.println("<h1>Test Submitted!</h1>");
            out.println("<p>Thank you for completing the test.</p>");
            out.println("<p>Your score:</p>");
            out.println("<p class='score'>" + String.format("%.2f", percentage) + "%</p>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        } catch (SQLException e) {
            e.printStackTrace(out);
        } finally {
            out.close();
        }
    }
}