import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/DeleteQuizServlet")
public class DeleteQuizServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DB_URL = "jdbc:mysql://admin.clo4o60s49oi.ap-south-1.rds.amazonaws.com:3306/OnlineQuizDB";
    private static final String DB_USER = "admin";
    private static final String DB_PASSWORD = "zeline12345";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int quizId = Integer.parseInt(request.getParameter("quizId"));
        String deleteResults = request.getParameter("deleteResults");

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            con.setAutoCommit(false); // Start transaction

            // Check if quiz exists
            String checkQuizQuery = "SELECT * FROM quizzes WHERE quiz_id = ?";
            try (PreparedStatement checkStmt = con.prepareStatement(checkQuizQuery)) {
                checkStmt.setInt(1, quizId);
                ResultSet rs = checkStmt.executeQuery();
                if (!rs.next()) {
                    out.println("<p style='color:red;'>Quiz with ID " + quizId + " does not exist!</p>");
                    return;
                }
            }

            // Optionally delete student results
            if ("yes".equalsIgnoreCase(deleteResults)) {
                String deleteQuizResultsQuery = "DELETE FROM quiz_results WHERE quiz_id = ?";
                try (PreparedStatement deleteResultsStmt = con.prepareStatement(deleteQuizResultsQuery)) {
                    deleteResultsStmt.setInt(1, quizId);
                    deleteResultsStmt.executeUpdate();
                }
            }

            // Always delete student responses associated with questions
            String deleteStudentResponsesQuery = "DELETE FROM student_responses WHERE question_id IN " +
                    "(SELECT question_id FROM questions WHERE quiz_id = ?)";
            try (PreparedStatement deleteResponsesStmt = con.prepareStatement(deleteStudentResponsesQuery)) {
                deleteResponsesStmt.setInt(1, quizId);
                deleteResponsesStmt.executeUpdate();
            }

            // Delete quiz questions
            String deleteQuestionsQuery = "DELETE FROM questions WHERE quiz_id = ?";
            try (PreparedStatement deleteQuestionsStmt = con.prepareStatement(deleteQuestionsQuery)) {
                deleteQuestionsStmt.setInt(1, quizId);
                deleteQuestionsStmt.executeUpdate();
            }

            // Delete quiz itself
            String deleteQuizQuery = "DELETE FROM quizzes WHERE quiz_id = ?";
            try (PreparedStatement deleteQuizStmt = con.prepareStatement(deleteQuizQuery)) {
                deleteQuizStmt.setInt(1, quizId);
                deleteQuizStmt.executeUpdate();
            }

            con.commit(); // Commit transaction
            out.println("<p style='color:green;'>Quiz with ID " + quizId + " and associated data successfully deleted.</p>");
        } catch (SQLException e) {
            e.printStackTrace(out);
            try {
                response.getWriter().println("<p style='color:red;'>Error occurred while deleting quiz. Rolling back changes.</p>");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}