
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/QuizManagementServlet")
public class QuizManagementServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://admin.clo4o60s49oi.ap-south-1.rds.amazonaws.com:3306/OnlineQuizDB";
    private static final String DB_USER = "admin";
    private static final String DB_PASSWORD = "zeline12345";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Retrieve parameters from the request
            String quizTitle = request.getParameter("title");
            String quizDescription = request.getParameter("description");
            String timeLimitStr = request.getParameter("timeLimit");
            String[] questions = request.getParameterValues("questions[]");
            String[] optionsA = request.getParameterValues("optionsA[]");
            String[] optionsB = request.getParameterValues("optionsB[]");
            String[] optionsC = request.getParameterValues("optionsC[]");
            String[] optionsD = request.getParameterValues("optionsD[]");
            String[] correctOptions = request.getParameterValues("correctOptions[]");

            int timeLimit = Integer.parseInt(timeLimitStr);

            // Insert quiz into quizzes table
            String insertQuizSQL = "INSERT INTO quizzes (title, description, time_limit) VALUES (?, ?, ?)";
            PreparedStatement quizStmt = conn.prepareStatement(insertQuizSQL, Statement.RETURN_GENERATED_KEYS);
            quizStmt.setString(1, quizTitle);
            quizStmt.setString(2, quizDescription);
            quizStmt.setInt(3, timeLimit);
            quizStmt.executeUpdate();

            // Get the generated quiz ID
            var rs = quizStmt.getGeneratedKeys();
            rs.next();
            int quizId = rs.getInt(1);

            // Insert questions into questions table
            String insertQuestionSQL = "INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement questionStmt = conn.prepareStatement(insertQuestionSQL);

            for (int i = 0; i < questions.length; i++) {
                questionStmt.setInt(1, quizId);
                questionStmt.setString(2, questions[i]);
                questionStmt.setString(3, optionsA[i]);
                questionStmt.setString(4, optionsB[i]);
                questionStmt.setString(5, optionsC[i]);
                questionStmt.setString(6, optionsD[i]);
                questionStmt.setString(7, correctOptions[i]);
                questionStmt.addBatch();
            }
            questionStmt.executeBatch();

            // Success response
            response.setContentType("text/html");
            response.getWriter().println("<h1>Quiz published successfully!</h1>");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while publishing the quiz.");
        }
    }
}