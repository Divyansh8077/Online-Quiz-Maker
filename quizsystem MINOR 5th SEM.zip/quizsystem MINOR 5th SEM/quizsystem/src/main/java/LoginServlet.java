
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public LoginServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve login credentials
        String username = request.getParameter("uname");
        String password = request.getParameter("pass");

        // Database connection parameters
        String jdbcURL = "jdbc:mysql://admin.clo4o60s49oi.ap-south-1.rds.amazonaws.com:3306/OnlineQuizDB";
        String dbUser = "admin"; // Replace with your database username
        String dbPassword = "zeline12345"; // Replace with your database password

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            con = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // SQL query to validate user
            String sql = "SELECT * FROM user WHERE email = ? AND password = ?";
            pst = con.prepareStatement(sql);
            pst.setString(1, username);
            pst.setString(2, password);

            rs = pst.executeQuery();

            if (rs.next()) {
                // User found
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                response.sendRedirect("startQuiz.html"); 
            } else {
                // Invalid credentials
                out.println("<script>");
                out.println("alert('Invalid username or password. Please try again.');");
                out.println("window.location.href='login.html';");
                out.println("</script>");
            }
        } catch (Exception e) {
            e.printStackTrace(out);
            out.println("<p style='color:red;'>An error occurred: " + e.getMessage() + "</p>");
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception ex) {
                ex.printStackTrace(out);
            }
            out.close();
        }
    }
}