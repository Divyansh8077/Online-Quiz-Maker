#include <stdio.h>

int main() {
    int n, first = 0, second = 1, next;
    printf("Enter the number of terms: ");
    scanf("%d", &n);
    
    printf("Fibonacci Series: ");
    while (n > 0) {
        if (n == 1) {
            printf("%d ", first);
            break;
        } else if (n == 2) {
            printf("%d %d ", first, second);
            break;
        } else {
            next = first + second;
            printf("%d ", next);
            first = second;
            second = next;
        }
        n--;
    }
    
    return 0;
}
